// columns_config.js
// Define as colunas do relatório e quais propriedades de cada linha exibir.
// Cada coluna possui uma chave (key) correspondente ao campo do objeto `row`,
// um cabeçalho (header) que será exibido na tabela e flags de formatação.

export const columnsConfig = [
  { key: 'id', header: 'ID', isMoney: false },
  { key: 'data', header: 'Data', isMoney: false },
  { key: 'valor', header: 'Valor', isMoney: true },
  { key: 'sexta', header: 'Sexta Parte', isMoney: true },
  { key: 'quinque_pct', header: 'Quinq %', isMoney: false },
  { key: 'quinque_val', header: 'Quinq (R$)', isMoney: true },
  { key: 'retp', header: 'RETP', isMoney: true },
  { key: 'sub_base', header: 'SubBase', isMoney: true },
  { key: 'ind_corr', header: 'Ind. Corr.', isMoney: false },
  { key: 'ind_hoje', header: 'Ind. Hoje', isMoney: false },
  { key: 'val_atual', header: 'Val. Atual', isMoney: true },
  { key: 'ferias', header: 'Férias', isMoney: true },
  { key: 'terco', header: '1/3 Férias', isMoney: true },
  { key: 'decimo', header: '13º', isMoney: true },
  { key: 'licenca', header: 'Licença Prêmio', isMoney: true },
  { key: 'sub_total', header: 'SubTotal', isMoney: true },
  { key: 'poup_factor', header: 'Fator Poup.', isMoney: false },
  { key: 'poup_val', header: 'Valor Poup.', isMoney: true },
  { key: 'selic_factor', header: 'Fator Selic', isMoney: false },
  { key: 'selic_val', header: 'Valor Selic', isMoney: true },
  { key: 'total', header: 'Total', isMoney: true },
];

export default columnsConfig;