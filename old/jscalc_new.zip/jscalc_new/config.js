// config.js
// Este arquivo contém valores padrão para o cálculo. Os valores podem ser
// lidos e atualizados pela interface do usuário em runtime.

export const CONFIG = {
  // Datas padrão (serão substituídas pelos inputs do usuário)
  dateStart: '2013-03-01',
  dateEnd: '2013-12-01',
  dateLimitIndices: '2013-12-01',
  dateLimitSelic: '2021-12-01',

  // Valor base padrão
  baseValue: 975,

  // Opções para incluir componentes
  includePrincipal: true,
  includeSexta: true,
  includeQuinq: true,
  includeRetp: false,
  includeFerias: true,
  includeTerco: true,
  includeDecimo: true,
  includeLic: true,

  // Taxas de desconto e honorários (em porcentagem)
  taxaDescPrev: 11, // previdenciário
  taxaHonorarios: 0,
  taxaCustas: 0,
};