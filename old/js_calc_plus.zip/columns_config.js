// columns_config.js
// Lista de colunas exibidas no relatório e mapeamento de propriedades
// do objeto de linha (`row`) gerado em calculadora.js para cabeçalhos e
// formatação. Cada coluna possui:
//   key: nome da propriedade no objeto `row`.
//   header: título exibido na tabela.
//   isMoney: true para formatar como valor monetário com 2 casas decimais,
//            false para números genéricos ou strings.

export const columnsConfig = [
  { key: 'id', header: 'ID', isMoney: false },
  { key: 'data', header: 'Data', isMoney: false },
  { key: 'valor', header: 'Valor', isMoney: true },
  { key: 'ale', header: 'ALE', isMoney: true },
  { key: 'piso', header: 'Piso', isMoney: true },
  { key: 'quinque_pct', header: 'Quinq %', isMoney: false },
  { key: 'quinque_val', header: 'Quinq (R$)', isMoney: true },
  { key: 'sexta', header: 'Sexta Parte', isMoney: true },
  { key: 'retp', header: 'RETP', isMoney: true },
  { key: 'sub_base', header: 'SubBase', isMoney: true },
  { key: 'ind_corr', header: 'Ind. Corr.', isMoney: false },
  { key: 'ind_hoje', header: 'Ind. Atual', isMoney: false },
  { key: 'val_atual', header: 'Val. Atual', isMoney: true },
  { key: 'ferias', header: 'Férias', isMoney: true },
  { key: 'terco', header: '1/3', isMoney: true },
  { key: 'decimo', header: '13º', isMoney: true },
  { key: 'licenca', header: 'Licença', isMoney: true },
  { key: 'sub_total', header: 'SubTotal', isMoney: true },
  { key: 'poup_acum', header: 'Fator Poup. (acum)', isMoney: false },
  { key: 'poup_val', header: 'Juros Poup.', isMoney: true },
  { key: 'sub_total_poup', header: 'SubTotal Poup.', isMoney: true },
  { key: 'selic_acum', header: 'Fator SELIC (acum)', isMoney: false },
  { key: 'selic_val', header: 'Juros SELIC', isMoney: true },
  { key: 'sub_total_selic', header: 'SubTotal SELIC', isMoney: true },
  { key: 'descPrev_val', header: 'Desc. Prev.', isMoney: true },
  { key: 'honor_val', header: 'Honor.', isMoney: true },
  { key: 'custas_val', header: 'Custas', isMoney: true },
  { key: 'total', header: 'Total', isMoney: true }
];

export default columnsConfig;