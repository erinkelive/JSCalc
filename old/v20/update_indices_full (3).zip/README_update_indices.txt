Pacote de atualização de índices (BCB/SGS)
------------------------------------------
Inclui:
- update_indices.py : atualiza `selic_data.js` (SGS 4390) e `poupanca_data.js` (SGS 195).

Novidade: NR por mês (DEFAULT). Use --nr-mode strict para exigir datas idênticas.

Uso:
  # SELIC (NR por mês)
  python update_indices.py selic --root . --out selic_data.js --nr-mode month --debug True

  # Poupança
  python update_indices.py poup --root . --out poupanca_data.js --nr-mode month --debug True

  # Verificar regressão por mês
  python update_indices.py verify --root . --target selic_data.js --nr-mode month

  # Restaurar último backup
  python update_indices.py restore-last --root . --target selic_data.js

  # Watch a cada 12h (SELIC)
  python update_indices.py watch --what selic --watch 43200 --root . --out selic_data.js --nr-mode month --debug False

Backups em ./backups/ (criado automaticamente).
