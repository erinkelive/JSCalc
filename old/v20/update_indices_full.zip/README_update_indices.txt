Pacote de atualização de índices (BCB/SGS)
------------------------------------------
Inclui:
- update_indices.py : atualiza `selic_data.js` e `poupanca_data.js`.

SELIC:
- Use 4390 (mensal) ou 1178 (diária->mensal) com --selic-source.

POUPANÇA:
- Série 25 (diária) até 2012-05, consolidada por mês (preferindo dia 01).
- Série 7828 (mensal) de 2012-06 em diante.
- Merge por mês com fallback (se faltar mês na 7828, usa 25).

Uso rápido:
  python update_indices.py selic --root . --out selic_data.js --nr-mode month --selic-source 1178 --debug True
  python update_indices.py poup  --root . --out poupanca_data.js --nr-mode month --debug True

Backups em ./backups/
