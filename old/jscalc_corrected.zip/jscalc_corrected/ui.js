// ui.js
// Script responsável por conectar a interface com a lógica de cálculo.

import { generateReport } from './calculadora.js';

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('gerarBtn');
  btn.addEventListener('click', () => {
    generateReport();
  });
});