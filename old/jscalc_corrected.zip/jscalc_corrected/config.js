// config.js
// Este arquivo contém valores padrão para o cálculo. Os valores podem ser
// lidos e atualizados pela interface do usuário em runtime.

export const CONFIG = {
  // Datas padrão (serão substituídas pelos inputs do usuário)
  dateStart: '2013-03-01',
  dateEnd: '2014-01-31',
  dateLimitIndices: '2021-11-30',
  dateLimitSelic: '2021-12-01',

  // Valor base padrão
  baseValue: 487.5,

  // Opções para incluir componentes
  includePrincipal: true,
  includeSexta: true,
  includeQuinq: true,
  includeRetp: true,
  includeFerias: true,
  includeTerco: true,
  includeDecimo: true,
  includeLic: true,

  // Taxas de desconto e honorários (em porcentagem)
  taxaDescPrev: 11, // previdenciário
  taxaHonorarios: 20,
  taxaCustas: 0,
};