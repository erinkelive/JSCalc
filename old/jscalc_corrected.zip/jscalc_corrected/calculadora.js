// calculadora.js
// Módulo responsável por gerar o relatório de cálculos.
// Ele lê as entradas do usuário, itera mês a mês e calcula todos os
// componentes (valor atualizado, férias proporcionais, 13º, licença prêmio etc.).

import { tabelaTJSP } from './tabela_data2.js';
import { selicFactors } from './selic_data.js';
import { poupancaFactors } from './poupanca_data.js';
import { aleValues } from './alevalores_data.js';
import columnsConfig from './columns_config.js';

// Utilidades de data
function parseDate(input) {
  // Converte uma string YYYY-MM-DD para um objeto Date na meia-noite.
  const [y, m, d] = input.split('-').map(x => parseInt(x, 10));
  return new Date(y, m - 1, d);
}

function toKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

function addMonths(date, count) {
  const d = new Date(date.getTime());
  d.setMonth(d.getMonth() + count);
  d.setDate(1);
  return d;
}

// Busca o índice de correção do mês (Ind. Corr.). Se não existir, retorna o último índice conhecido.
function getIndCorr(key) {
  if (tabelaTJSP.hasOwnProperty(key)) {
    return tabelaTJSP[key];
  }
  // Busca chave anterior disponível
  let [year, month] = key.split('-').map(x => parseInt(x, 10));
  // retrocede até encontrar
  for (let i = 0; i < 24; i++) {
    // decrementa um mês
    month -= 1;
    if (month < 1) {
      month = 12;
      year -= 1;
    }
    const k = `${year}-${String(month).padStart(2, '0')}`;
    if (tabelaTJSP.hasOwnProperty(k)) {
      return tabelaTJSP[k];
    }
  }
  return 1; // fallback
}

// Busca fator de poupança para a data informada
function getPoupancaFactor(key) {
  for (const item of poupancaFactors) {
    if (item.date.startsWith(key)) {
      return item.factor;
    }
  }
  return 0;
}

// Busca fator selic para a data informada
function getSelicFactor(key) {
  for (const item of selicFactors) {
    if (item.date.startsWith(key)) {
      return item.factor;
    }
  }
  return 0;
}

// Obtém o valor do ALE (ou RETP) mais recente até a data (inclusive).
// Caso não exista valor anterior à data, retorna 0.
function getAle(date) {
  let value = 0;
  for (const item of aleValues) {
    const itemDate = parseDate(item.date);
    if (itemDate <= date) {
      value = item.value;
    }
  }
  return value;
}

// Formata número como moeda brasileira
function formatMoney(value) {
  return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Formata valores genéricos
function formatValue(value) {
  return Number.isFinite(value) ? value.toLocaleString('pt-BR', { minimumFractionDigits: 4, maximumFractionDigits: 4 }) : '';
}

// Gera relatório e injeta na tabela
export function generateReport() {
  const startDateStr = document.getElementById('startDate').value;
  const endDateStr = document.getElementById('endDate').value;
  const limitIndicesStr = document.getElementById('limitIndices').value;
  const limitSelicStr = document.getElementById('limitSelic').value;

  const baseValueInput = parseFloat(document.getElementById('baseValue').value) || 0;
  const quinValue = parseFloat(document.getElementById('quinValue').value)  || 0;
  const includePrincipal = document.getElementById('includePrincipal').checked;
  const includeSexta = document.getElementById('includeSexta').checked;
  const includeQuinq = document.getElementById('includeQuinq').checked;
  const includeRetp = document.getElementById('includeRetp').checked;
  const includeFerias = document.getElementById('includeFerias').checked;
  const includeTerco = document.getElementById('includeTerco').checked;
  const includeDecimo = document.getElementById('includeDecimo').checked;
  const includeLic = document.getElementById('includeLic').checked;
  const taxaPrev = parseFloat(document.getElementById('taxaPrev').value) || 0;
  const taxaHonor = parseFloat(document.getElementById('taxaHonor').value) || 0;
  const taxaCustas = parseFloat(document.getElementById('taxaCustas').value) || 0;

  const startDate = parseDate(startDateStr);
  const endDate = parseDate(endDateStr);
  const limitIndices = parseDate(limitIndicesStr);
  const limitSelic = parseDate(limitSelicStr);

  // Calcula indice hoje global (usado para atualizar valores). Utiliza data limite de índices.
  const indHojeKey = toKey(limitIndices);
  const indHojeGlobal = getIndCorr(indHojeKey);

  let rows = [];
  let currentDate = new Date(startDate.getTime());
  let idCounter = 1;
  let mesesFerias = 0;
  let mesesLic = 0;

  while (currentDate <= endDate) {
    const key = toKey(currentDate);
    const indCorr = getIndCorr(key);
    //const retpVal = includeRetp ? getRetp(currentDate) : 0;
    // Se incluir RETP/ALE, busca o valor vigente para a data corrente
    const retpVal = includeRetp ? getAle(currentDate) : 0;

    // Quinquênio: 5% a cada 5 anos (60 meses)
    const totalMonths = ((currentDate.getFullYear() - startDate.getFullYear()) * 12) +
      (currentDate.getMonth() - startDate.getMonth());
    // Calcula o percentual de quinquênio. Se o usuário forneceu um valor inicial
    // (quinValue > 0), ele será aplicado durante os primeiros 5 anos. A cada
    // intervalo de 60 meses, acrescenta-se 5 pontos percentuais ao valor inicial.
    // Caso não haja valor inicial, o percentual será 0% nos primeiros 5 anos e
    // aumentará 5% a cada 5 anos completos.
    let quinquePct = 0;
    if (includeQuinq) {
      const intervals = Math.floor(totalMonths / 60);
      if (quinValue > 0) {
        quinquePct = parseFloat(quinValue) + intervals * 5;
      } else {
        quinquePct = intervals * 5;
      }
    }

    const quinqueVal = includeQuinq ? (baseValueInput * (quinquePct / 100)) : 0;

    const sextaVal = includeSexta ? ((baseValueInput + quinqueVal) / 6) : 0;
    const principalVal = includePrincipal ? baseValueInput : 0;

    const subBase = principalVal + sextaVal + quinqueVal + retpVal;

    const valAtual = (indCorr !== 0 ? (subBase / indCorr) * indHojeGlobal : subBase);

    // Férias / 13º / 1/3 (proporcionais)
    let feriasVal = 0;
    let tercoVal = 0;
    let decimoVal = 0;
    if (includeFerias || includeTerco || includeDecimo) {
      mesesFerias += 1;
    }

    // paga férias (e extras) se completou 12 meses ou se é a última linha
    const isLastRow = (addMonths(currentDate, 1) > endDate);
    if ((mesesFerias >= 12 || isLastRow) && (includeFerias || includeTerco || includeDecimo)) {
      feriasVal = includeFerias ? ((valAtual / 12) * mesesFerias) : 0;
      tercoVal = includeTerco ? (feriasVal / 3) : 0;
      decimoVal = includeDecimo ? feriasVal : 0;
      mesesFerias = 0;
    }

    // Licença Prêmio
    let licVal = 0;
    if (includeLic) {
      mesesLic += 1;
      if (mesesLic >= 60) {
        // completou 5 anos: 3 salários
        licVal = valAtual * 3;
        mesesLic = 0;
      } else if (isLastRow) {
        // proporcional no último mês
        licVal = valAtual * (mesesLic / 20);
        mesesLic = 0;
      }
    }

    const subTotal = valAtual + feriasVal + tercoVal + decimoVal + licVal;

    // Poupança e Selic: aplica fator mensal de acordo com data limite
    let poupFactor = 0;
    if (currentDate < limitSelic) {
      // usa poupança
      poupFactor = getPoupancaFactor(key);
    }
    const poupVal = subTotal * poupFactor;

    let selicFactor = 0;
    if (currentDate >= limitSelic) {
      selicFactor = getSelicFactor(key);
    }
    const selicVal = subTotal * selicFactor;

    let totalVal = subTotal + poupVal + selicVal;

    // Aplica descontos e honorários sobre totalVal (opcionais)
    const descPrev = totalVal * (taxaPrev / 100) * -1;
    const honorVal = totalVal * (taxaHonor / 100);
    const custasVal = totalVal * (taxaCustas / 100);
    totalVal = totalVal + descPrev + honorVal + custasVal;

    rows.push({
      id: idCounter++,
      data: key,
      valor: principalVal,
      sexta: sextaVal,
      quinque_pct: quinquePct ? `${quinquePct}%` : '0%',
      quinque_val: quinqueVal,
      retp: retpVal,
      sub_base: subBase,
      ind_corr: indCorr,
      ind_hoje: indHojeGlobal,
      val_atual: valAtual,
      ferias: feriasVal,
      terco: tercoVal,
      decimo: decimoVal,
      licenca: licVal,
      sub_total: subTotal,
      poup_factor: poupFactor,
      poup_val: poupVal,
      selic_factor: selicFactor,
      selic_val: selicVal,
      //incluido coluna desconto previdenciario
      descPrev_val: descPrev,
      total: totalVal,
    });

    // avança para o próximo mês
    currentDate = addMonths(currentDate, 1);
  }

  // exibe na interface
  displayTable(rows);
}

// Constrói e exibe a tabela de resultados.
function displayTable(rows) {
  const container = document.getElementById('tableContainer');
  container.innerHTML = '';

  const table = document.createElement('table');
  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  for (const col of columnsConfig) {
    const th = document.createElement('th');
    th.textContent = col.header;
    headerRow.appendChild(th);
  }
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  rows.forEach(row => {
    const tr = document.createElement('tr');
    columnsConfig.forEach(col => {
      const td = document.createElement('td');
      let val = row[col.key];
      if (col.isMoney) {
        val = formatMoney(val);
      } else {
        if (typeof val === 'number') {
          val = formatValue(val);
        }
      }
      td.textContent = val;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  container.appendChild(table);
}