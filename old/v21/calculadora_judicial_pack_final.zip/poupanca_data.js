// Exemplo de estrutura (mesmo espírito do selic_data.js)
const poupancaFactors = [
  // { date: 'YYYY-MM-DD', factor: 0.0037 }, // 0.37% no mês, por exemplo
];
